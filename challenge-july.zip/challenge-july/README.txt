Struktur yang Jelas: Gunakan elemen semantic, seperti <header>, <nav>, <main>, <section>, <article>, dan <footer>, untuk menggambarkan struktur halaman dengan jelas.



Buat 1 buah website, yang isinya adalah landing page, dengan requirement:
- Tujuan / Pesan yang ingin disampaikan harus jelas.
- HTML, HTML Semantic, CSS (box model, layout: grid/flexbox), CSS Responsive, Javascript, Git.
- Tanggal 31 Juli 2023 (hari senin minggu depan).